# My Website

This is a simple static website ready to be hosted on GitHub Pages.

## How to Publish

1. Upload all files to a new GitHub repository.
2. Go to repository Settings > Pages.
3. Under "Source", select "Deploy from a branch", and choose the main branch.
4. Your site will be live at: `https://your-username.github.io/your-repo-name/`
