// script.js

let currentLanguage = 'ar';  // Default language is Arabic
let wardrobe = [];
let remainingImages = 10; // عدد الصور المتبقية

// دالة لتغيير اللغة
function changeLanguage(lang) {
    currentLanguage = lang;
    updateLanguage();
}

// دالة لتحديث النصوص حسب اللغة
function updateLanguage() {
    if (currentLanguage === 'ar') {
        document.getElementById('app-title').innerText = 'تطبيق SSO';
        document.getElementById('description').innerText = 'اختر لغتك وابدأ بإضافة صور لملابسك.';
        document.getElementById('style-text').innerText = 'اختر الستايل المفضل:';
        document.getElementById('no-images-msg').innerText = 'لم تقم برفع أي صورة بعد!';
        document.getElementById('remainingImages').innerText = `بقي لرفع ${remainingImages} صور`;
        document.getElementById('result').innerText = '';
        document.getElementById('savedWardrobe').innerText = 'حفظ الخزانة';
    } else {
        document.getElementById('app-title').innerText = 'SSO Application';
        document.getElementById('description').innerText = 'Choose your language and start adding your clothes images.';
        document.getElementById('style-text').innerText = 'Choose your preferred style:';
        document.getElementById('no-images-msg').innerText = 'You haven\'t uploaded any images yet!';
        document.getElementById('remainingImages').innerText = `You can upload ${remainingImages} more images`;
        document.getElementById('result').innerText = '';
        document.getElementById('savedWardrobe').innerText = 'Save Wardrobe';
    }
}

// دالة لتحميل الصور
document.getElementById('upload').addEventListener('change', function(event) {
    let files = event.target.files;
    let uploadedCount = files.length;

    // إذا كانت الصور أكثر من المتاح (10 صور) لن يسمح برفع المزيد
    if (remainingImages - uploadedCount < 0) {
        alert('لقد قمت برفع الحد الأقصى للصور! يمكنك رفع 10 صور فقط.');
        return;
    }

    for (let i = 0; i < uploadedCount; i++) {
        if (remainingImages <= 0) break;

        let reader = new FileReader();
        reader.onload = function(e) {
            let imgElement = document.createElement('img');
            imgElement.src = e.target.result;
            imgElement.classList.add('uploaded-image');
            wardrobe.push(e.target.result); // حفظ الصورة في الخزانة
            document.getElementById('wardrobeImages').appendChild(imgElement);
        };
        reader.readAsDataURL(files[i]);
        remainingImages--;
        document.getElementById('remainingImages').innerText = `بقي لرفع ${remainingImages} صور`;
    }

    if (remainingImages === 0) {
        document.getElementById('remainingImages').innerText = 'لقد وصلت إلى الحد الأقصى من الصور!';
    }
});

// دالة لاختيار ال
